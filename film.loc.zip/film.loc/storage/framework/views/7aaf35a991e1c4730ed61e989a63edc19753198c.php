
<?php $__env->startSection('content'); ?>
<div class="row p-3">
    <div class="card col-4">
        <img src="<?php echo e($film->poster); ?>" class="card-img-top" alt="<?php echo e($film->title); ?>">
    </div>
    <div class="card col-4">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($film->title); ?></h5>
            <?php $__currentLoopData = $film->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="badge text-bg-primary"><?php echo e($genre->title); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p class="card-text">Дата выхода: <?php echo e($film->date); ?></p>
            <p class="card-text">Режиссёр: <?php echo e($film->director->name); ?></p>
            <!--a href="/films/<?php echo e($film->id); ?>" class="btn btn-success">Изменить</a-->
        </div>
    </div>
    <div class="card col-4">
        <div class="card-body">
            <p>Актёры:</p>
            <ul>
                <?php $__currentLoopData = $film->actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="row">
                    <p class="col"><?php echo e($actor->name); ?></p>
                    <?php if(Auth::check() and Auth::user()->isAdmin()): ?>
                    <div class="col">
                        <form action="/films/<?php echo e($film->id); ?>/actors/<?php echo e($actor->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("delete"); ?>
                            <button class="bnt bnt-danger">Удалить</button>
                        </form>
                    </div>
                    <?php endif; ?>

                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <!--a href="/films/<?php echo e($film->id); ?>" class="btn btn-success">Изменить</a-->
        </div>
    </div>

    <div class="row">
        <?php $__currentLoopData = $film->posters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poster): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3 col-4">
            <img src="<?php echo e($poster->url); ?>" alt="poster">
            <?php if(Auth::check() and Auth::user()->isAdmin()): ?>
            <div class="card-body">
                <form action="/films/<?php echo e($film->id); ?>/posters/<?php echo e($poster->id); ?>" method="POST">"
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn btn-danger">Удалить</button>
                </form>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if(!Auth::check() or Auth::check() and !Auth::user()->isAdmin()): ?>
    <div class="row">
        <?php $__currentLoopData = $film->ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card col-3">
            <h2><?php echo e($rating->user->name); ?></h2>
            <h3><?php echo e($rating->rating); ?></h3>
            <div class="card-body">
                <p><?php echo e($rating->review); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin()): ?>
    <div class="row">
        <div class="col">
            <form action="/films/<?php echo e($film->id); ?>" method="POST" class="m-3">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="mb-3">
                    <label for="actor">Актёр</label>
                    <select name="actor" id="actor" class="form-select">
                        <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($actor->id); ?>"><?php echo e($actor->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-3">
                    <button class="btn btn-primary">Добавить</button>
                </div>
            </form>
        </div>
        <div class="col">
            <form action="/films/<?php echo e($film->id); ?>" method="POST" enctype="multipart/form-data" class="m-3">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="mb-3">
                    <label for="poster">Скриншот</label>
                    <input type="file" class="form-control" name="poster">
                </div>
                <div class="mb-3">
                    <button class="btn btn-primary">Добавить</button>
                </div>
            </form>
        </div>
        <div class="col">
            <form action="/films/<?php echo e($film->id); ?>" method="POST" class="m-3">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="mb-3">
                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" value="<?php echo e($genre->id); ?>" id="genre<?php echo e($genre->id); ?>" name="title[]">
                        <label class="form-check-label" for="genre<?php echo e($genre->id); ?>"><?php echo e($genre->title); ?></label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mb-3">
                    <button class="btn btn-primary">Добавить</button>
                </div>
            </form>
        </div>
    </div>
    <h2>Отзывы</h2>
    <?php $__currentLoopData = $film->ratingsforchek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col"><?php echo e($rating->user->name); ?></div>
        <div class="col"><?php echo e($rating->rating); ?></div>
        <div class="col"><?php echo e($rating->review); ?></div>
        <div class="col">
            <form action="/films/<?php echo e($film->id); ?>/ratings/<?php echo e($rating->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <button class="btn btn-success">Одобрить</button>
            </form>
        </div>
        <div class="col">
            <form action="/films/<?php echo e($film->id); ?>/ratings/<?php echo e($rating->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button class="btn btn-danger">Удалить</button>
            </form>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <h2>Отзывы</h2>
    <div class="row">
        <div class="col">
            <form action="/films/<?php echo e($film->id); ?>/ratings" method="POST" class="m-3">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="rating" class="form-label">Оценка</label>
                    <select class="form-select" name="rating" id="rating">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="review" class="form-label">Отзыв</label>
                    <textarea name="review" id="review" class="form-control"></textarea>
                </div>
                <div class="mb-3">
                    <button class="btn btn-primary">Добавить</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\film.loc\resources\views/film.blade.php ENDPATH**/ ?>