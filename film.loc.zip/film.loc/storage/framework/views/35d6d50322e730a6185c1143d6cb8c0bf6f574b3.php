<h2>События</h2>
<form class="row g-3" m-3 action="/events" method="POST">
            <?php echo csrf_field(); ?>
            <label for="events" class="form-label">События</label>
            <input type="text" class="form-control" id="events">

        </form>
        <table class="table-primary">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="table-primary">
                <td class="table-primary"></td>
                <td>
                    <form action="/event/<?php echo e($event->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
 
                </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table><?php /**PATH C:\OpenServer\domains\film.loc\resources\views/admin/event.blade.php ENDPATH**/ ?>