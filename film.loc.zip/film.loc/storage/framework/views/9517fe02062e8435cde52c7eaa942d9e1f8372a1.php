
<?php $__env->startSection('content'); ?>
<h1>Привет, <?php echo e(Auth::user()->name); ?></h1>
<div class="row mt-3">
    <?php $__currentLoopData = Auth::user()->films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card col-3">
        <a href="/films/<?php echo e($film->id); ?>">
            <img src="<?php echo e($film->poster); ?>" class="card-img-top" alt="<?php echo e($film->title); ?>">
        </a>
        <div class="card-body">
            <h5 class="card-title"><?php echo e($film->title); ?></h5>
            <h6 class="card-text">Рейтинг: <?php echo e($film->rating); ?></h6>
            <?php $__currentLoopData = $film->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="badge text-bg-primary"><?php echo e($genre->title); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p class="card-text">Дата выхода:<?php echo e($film->date); ?></p>
            <p class="card-text">Режиссёр:<?php echo e($film->director->name); ?></p>
            <form action="/favorites <?php echo e($film->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button class="btn btn-success">Убрать</button>
            </form>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\film.loc\resources\views/lk.blade.php ENDPATH**/ ?>