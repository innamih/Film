<h2></h2>
<form class="row g-3" m-3 action="/genres" method="POST">
            <?php echo csrf_field(); ?>
            <label for="genre" class="form-label">Название жанра</label>
            <input type="text" class="form-control" id="genre" name="title">
            <button type="submit" class="btn btn-primary">Добавить</button>
        </form>
        <table class="table-primary">
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="table-primary">
                <td class="table-primary"><?php echo e($genre->title); ?></td>
                <td>
                    <form action="/genres/<?php echo e($genre->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                <button class="btn btn-danger">Удалить</button>
                </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table><?php /**PATH C:\OpenServer\domains\film.loc\resources\views/admin/genre.blade.php ENDPATH**/ ?>