
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-2">
        <div class="row">
            <form action="/" method="POST" class="m-3">
                <?php echo csrf_field(); ?>
                <div class="col-12">
                    <h3>Жанры</h3>
                    <div class="mb-3">
                        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" value="<?php echo e($genre->id); ?>" id="genre<?php echo e($genre->id); ?>" name="genre[]">
                            <label class="form-check-label" for="genre<?php echo e($genre->id); ?>"><?php echo e($genre->title); ?></label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-12">
                    <h3>Актёры</h3>
                    <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" value="<?php echo e($actor->id); ?>" id="actor<?php echo e($actor->id); ?>" name="actors[]">
                        <label class="form-check-label" for="actor<?php echo e($actor->id); ?>"><?php echo e($actor->name); ?></label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="col-12">
                    <h3>Режиссёры</h3>
                    <?php $__currentLoopData = $directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" value="<?php echo e($director->id); ?>" id="director<?php echo e($director->id); ?>" name="directors[]">
                        <label class="form-check-label" for="director<?php echo e($director->id); ?>"><?php echo e($director->name); ?></label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="col-12">
                    <h3>Дата выпуска</h3>
                    <div class="mb-3">
                        <label for="dateForm" class="form-label">c</label>
                        <input type="date" id="dateFrom" name="dateFrom" class="form-control">
                    </div>

                    <div class="mb-3">
                        <label for="dateTo" class="form-label">по</label>
                        <input type="date" id="dateTo" name="dateTo" class="form-control">
                    </div>

                </div>
                <div class="col-12">
                    <div class="mb-3">
                        <label for="dateForm" class="form-label">Упорядочить</label>
                        <select id="dateFrom" name="order" class="form-select">
                            <option value="0">Не упорядочивать</option>
                            <option value="1">Сначала старые</option>
                            <option value="2">Сначала новые</option>
                            <option value="3">Сначала с высоким рейтингом</option>
                            <option value="4">Сначала с низким рейтнгом</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3" col-12>
                    <button class="btn btn-primary">Показать</button>
                </div>
            </form>
        </div>
    </div>

<div class="col-10">
    <div class="row mt-3">
        <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card col-3">
            <a href="/films/<?php echo e($film->id); ?>">
                <img src="<?php echo e($film->poster); ?>" class="card-img-top" alt="<?php echo e($film->title); ?>">
            </a>
            <div class="card-body">
                <h5 class="card-title"><?php echo e($film->title); ?></h5>
                <h6 class="card-text">Рейтинг: <?php echo e($film->rating); ?></h6>
                <?php $__currentLoopData = $film->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge text-bg-primary"><?php echo e($genre->title); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <p class="card-text">Дата выхода:<?php echo e($film->date); ?></p>
                <p class="card-text">Режиссёр:<?php echo e($film->director->name); ?></p>
                <?php if(Auth::check() and Auth::user()->isAdmin()): ?>
                <a href="/films/<?php echo e($film->id); ?>" class="btn btn-success">Изменить</a>
                <?php endif; ?>
                <?php if(Auth::check() and !Auth::user()->isAdmin()): ?>
                <form action="/favorites" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value=<?php echo e($film->id); ?> name="film">
                    <button class="btn btn-success">В избранное</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</div>
<div class="d-flex justify-content-center">
    <?php echo e($films->links()); ?>    
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\film.loc\resources\views/welcome.blade.php ENDPATH**/ ?>