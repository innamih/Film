<h2></h2>
<form class="row g-3" m-3 action="/directors" method="POST">
    <?php echo csrf_field(); ?>
    <label for="staticEmail2" class="form-label">ФИО</label>
    <input type="text" class="form-control" id="staticEmail2" name="name">
    <button type="submit" class="btn btn-primary">Добавить</button>
</form>
<table class="table-primary">
    <?php $__currentLoopData = $directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="table-primary">
        <td class="table-primary"><?php echo e($director->name); ?></td>
        <td>
            <form action="/directors/<?php echo e($director->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button class="btn btn-danger">Удалить</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php if($errors->any()): ?>
<div class="alert alert-danger" role="alert">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?><?php /**PATH C:\OpenServer\domains\film.loc\resources\views/admin/directorform.blade.php ENDPATH**/ ?>