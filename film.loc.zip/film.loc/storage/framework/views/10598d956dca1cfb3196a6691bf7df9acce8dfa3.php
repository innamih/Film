<form action="/films" method="POST" enctype="multipart/form-data" class="m-3">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="title">Название фильма</label>
        <input type="text" class="form-control" id="title" name="title">
    </div>
    <div class="mb-3">
        <label for="date">Дата выпуска</label>
        <input type="date" id="date" class="form-control" name="date">
    </div>
    <div class="mb-3">
        <label for="poster">Постер</label>
        <input type="file" id="poster" name="poster" class="form-control">
    </div>
    <div class="mb-3">
        <label for="events">Новости кино</label>
        <input type="file" id="events" name="body" class="form-control">
    </div>
    <div class="mb-3">
        <label for="director">Режиссёр</label>
        <select class="form-select" id="director" name='director_id'>
            <?php $__currentLoopData = $directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($director->id); ?>"><?php echo e($director->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3">
        <button class="bth bth-primary">Сохранить</button>
    </div>
</form>
<div class="films row">
    <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card col-3">
        <img src="<?php echo e($film->poster); ?>" class="card-img-top" alt="<?php echo e($film->title); ?>">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($film->title); ?></h5>
            <?php $__currentLoopData = $film->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="badge text-bg-primary"><?php echo e($genre->title); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p class="card-text">Дата выхода:<?php echo e($film->date); ?></p>
            <p class="card-text">Режиссёр:<?php echo e($film->director->name); ?></p>
            <a href="/films/<?php echo e($film->id); ?>" class="btn btn-success">Изменить</a>
            <form action="/films/<?php echo e($film->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field("delete"); ?>
                <button class="btn btn-danger">Удалить</button>
            </form>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\OpenServer\domains\film.loc\resources\views/admin/films.blade.php ENDPATH**/ ?>