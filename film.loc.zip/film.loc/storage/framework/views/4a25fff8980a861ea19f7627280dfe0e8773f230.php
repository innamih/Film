
<?php $__env->startSection('content'); ?>
<div class="row mt-3"></div>
<?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card col-3">
    <a href="/films/<?php echo e($film->id); ?>">
        <img src="<?php echo e($film->poster); ?>" class="card-img-top" alt="<?php echo e($film->title); ?>">
    </a>
    <div class="card-body">
        <h5 class="card-title"><?php echo e($film->title); ?></h5>
        <h6 class="card-text">Рейтинг: <?php echo e($film->reting); ?></h6>
        <?php $__currentLoopData = $film->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span class="badge text-bg-primary"><?php echo e($genre->title); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <p class="card-text">Дата выхода:<?php echo e($film->date); ?></p>
        <p class="card-text">Режиссёр:<?php echo e($film->director->name); ?></p>
        <?php if(Auth::check() and Auth::user()->isAdmin()): ?>
        <a href="/films/<?php echo e($film->id); ?>" class="btn btn-success">Изменить</a>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\film.loc\resources\views/search.blade.php ENDPATH**/ ?>